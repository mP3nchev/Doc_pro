<div class="wrap">
    <h1>Създай документ</h1>
    
    <div class="docgen-create-form">
        <?php include DOCGEN_PLUGIN_PATH . 'templates/create-document-form.php'; ?>
    </div>
</div>
